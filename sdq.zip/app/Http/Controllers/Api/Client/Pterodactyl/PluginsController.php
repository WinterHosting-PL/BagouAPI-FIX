<?php

namespace App\Http\Controllers\Api\Client\Pterodactyl;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\License;
use App\Models\BukkitResult;
use App\Models\PolymartResult;
use Config;

class PluginsController extends BaseController
{
    function addtodb(Request $request) {
        $key = config('api.key');
        $response = Http::withHeaders(['Authorization' => $key, 'transactionid' => $request->id])
        ->post('https://pterodactylmarket.com/api/seller/transaction?Authorization')
        ->json();
        if($response['valid'] && $response['transaction_status'] == "COMPLETE") {
            $addon = Http::withHeaders(['resourceid' => $response['resource_id'], "query" => "info"])
            ->post('https://pterodactylmarket.com/api/public/resource')
            ->json();
            $user = Http::withHeaders(['Authorization' => $key, "userid" => $response['buyer_id']])
            ->post('https://pterodactylmarket.com/api/seller/user')
            ->json();
            License::create(['blacklisted' => $user['banned'], 'buyer' => $user['username'], 'fullname' => $addon['name'], 'ip' => [$request->ip()], 'maxusage' => 2, 'name' => $response['resource_id'], 'transaction' => $request->id, 'usage' => 1, "buyerid" => $response['buyer_id']]);
            if($user['banned']) {
                return response()->json([
                    'message' => 'User blacklisted.'
                ], 418);
            } else {
                if(326 !== $response['resource_id']) {
                    return response()->json([
                        'message' => 'Not the good addon.'
                    ], 400);
                }
                if($addon->usage > $addon->maxusage) {
                    return response()->json([
                        'message' => 'Too many usage.'
                    ], 400);
                }
                return response()->json([
                    'message' => 'Good.'
                ], 200);;
            }
        } else {
            return response()->json([
                'message' => 'Transaction is not valid.'
            ], 400);
        }
    }
    function checkLicense(Request $request) {
        $addon = License::where("transaction", '=', $request->id)->first();
        if (!$addon) {
            return $this->addtodb($request);
        } else {
            $key = config('api.key');

            if($addon->blacklisted) {
                return response()->json([
                    'message' => 'User blacklisted.'
                ], 418);
            }
            $user = Http::withHeaders(['Authorization' => $key, "userid" => $addon->buyerid])
            ->post('https://pterodactylmarket.com/api/seller/user')
            ->json();
            if($user['banned']) {
                License::where("transaction", '=', $request->id)->update(["blacklisted" => true]);
                return response()->json([
                    'message' => 'User blacklisted.'
                ], 418);
            } else {
                if(326 !== $addon->name) {
                    return response()->json([
                        'message' => 'Not the good addon.'
                    ], 400);
                }
                return response()->json([
                    'message' => 'Good.'
                ], 200);;
            }
        }
    }
    public function getBukkit(Request $request) {
        $license = $this->checkLicense($request);
        if($license->getStatusCode() === 200) {
            if ($request->searchFilter) {
                $url = "https://dev.bukkit.org/search?projects-page=$request->page?&search=$request->search";
            } else {
                $data = BukkitResult::where('page', '=', $request->page)->first();
                if($data) {
                    if($data->updated_at->diffInHours(now())<24) {
                        return $data->result;
                    }

                }
                $url = "https://dev.bukkit.org/bukkit-plugins?page=$request->page";
            }
            $tablo_liens=array();
            $subject = file_get_contents($url);
            preg_match_all('/<a\s+.*?href=[\"\']?([^\"\' >]*)[\"\']?[^>]*>(.*?)<\/a>/i', $subject, $matches, PREG_PATTERN_ORDER);
            foreach($matches[1] as $match)
              {
                if (str_starts_with($match, '/projects')) {
                    $pluginlink = $match;
                    if ($request->searchFilter) {
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, "https://dev.bukkit.org$pluginlink/files/latest");
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
                    curl_exec($ch);
                    $redirectedUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
                    curl_close($ch);
                    $downloadurl = "$redirectedUrl/files/latest";
                    }
                    else {
                        $downloadurl = "https://dev.bukkit.org$pluginlink/files/latest";
                    }
                    $first = strstr($subject, "<a href=\"$pluginlink\">");
                    $second = strstr($first, "</a>", true);
                    $third= str_replace("<a href=\"$pluginlink\">", '', $second);
                    $pluginname = $third;
                    if ($request->searchFilter) {
                        $firsticon= strstr($subject, "<a class=\"results-image e-avatar64 \" href=\"$pluginlink\"");
                        $secondicon = strstr($firsticon, "</a>", true);
                        $thirdicon = str_replace("<a class=\"results-image e-avatar64 \" href=\"$pluginlink\"", '', $secondicon);
                        preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $thirdicon, $fourthicon);
                        $iconurl = str_replace('"/', "", implode(', ', $fourthicon[0]));
                    } else {
                        $firsticon= strstr($subject, "<a class=\"e-avatar64 \" href=\"https://dev.bukkit.org$pluginlink\"");
                        $secondicon = strstr($firsticon, "</a>", true);
                        $thirdicon = str_replace("<a class=\"e-avatar64 \" href=\"https://dev.bukkit.org$pluginlink\"", '', $secondicon);
                        preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $thirdicon, $fourthicon);
                        $iconurl = str_replace('"/', "", implode(', ', $fourthicon[0]));
                    }
                    if ($request->searchFilter) {
                        $firstdesc = strstr($subject, $pluginname);
                        $seconddesc = strstr($firstdesc, '<div class="results-summary">');
                        $thirddesc = strstr($seconddesc, "</div>", true);
                        $fourthdesc= str_replace('<div class="results-summary">', '', $thirddesc);
                        $fifthdesc= str_replace('<p>', '', $fourthdesc);
                        $sixthdesc = str_replace('</p>', '', $fifthdesc);
                        $desc = $sixthdesc;
                    } else {
                        $firstdesc = strstr($subject, $pluginname);
                        $seconddesc = strstr($firstdesc, '<div class="description">');
                        $thirddesc = strstr($seconddesc, "</div>", true);
                        $fourthdesc= str_replace('<div class="description">', '', $thirddesc);
                        $fifthdesc= str_replace('<p>', '', $fourthdesc);
                        $sixthdesc = str_replace('</p>', '', $fifthdesc);
                        $desc = $sixthdesc;
                    }
                    $installed = 0;
                    $installdate = date('Y-m-d H:i');
                    $downloadlink = Http::get($downloadurl)->transferStats->getRequest()->getUri()->jsonSerialize();
                    $downloadname = basename(parse_url($downloadlink, PHP_URL_PATH));
                         $tablo_liens[] = array(
                             "name"=>$pluginname,
                             "downloadlink"=> $downloadlink,
                             "filename" => $downloadname,
                             "installed" => $installed,
                             "installdate" => $installdate,
                             "links" => [
                                 "discussion" => $pluginlink
         
                             ],
                             "file" => [
                                 "type" => '.jar'
                             ],
                             "icon"=> [
                                 "url" => $iconurl
                             ],
                             'tag' => $desc,
                        );
    
                    
                    
               
                }
            }
            if(!$request->search) {
                BukkitResult::where('page', '=', $request->page)->delete();
                BukkitResult::create(['page' => $request->page, 'result' => json_encode($tablo_liens)]);
            }
            return json_encode($tablo_liens); 
        } else {
            return $license;
        };
    }
    public function getSpigot(Request $request) {
        $license = $this->checkLicense($request);
        $fields = "id,name,tag,file,testedVersions,links,external,version,author,category,rating,icon,releaseDate,updateDate,downloads,premium";
        $size = 20;
        if($request->size) {
            $size = $request->size;
        }
        if($license->getStatusCode() === 200) {
            if($request->search) {
                return Http::get("https://api.spiget.org/v2/search/resources/$request->search?size=$size&page=$request->page&sort=-downloads/resources")->json();
            }
            if($request->category == 4) {
                return Http::get("https://api.spiget.org/v2/resources?size=$size&page=$request->page&sort=-downloads&fields=$fields")->json();
            } else {
                return Http::get("https://api.spiget.org/v2/categories/$request->category/resources?size=$size&page=$request->page&sort=-downloads&fields=$fields")->json();
            }
        } else {
            return $license;
        };
    }
    public function getPolymart(Request $request) {
        $license = $this->checkLicense($request);
        $start = $request->page*20-20;

        if($license->getStatusCode() === 200) {
            if($request->search) {
                return Http::get("https://api.polymart.org/v1/search?limit=20&start=$start&query=$request->earch&premium=0")->json();
            }
            $data = PolymartResult::where('page', '=', $request->page)->first();
            if($data) {
                if($data->updated_at->diffInHours(now())<24) {
                    return $data->result;
                }

            }
            $result = Http::get("https://api.polymart.org/v1/search?limit=20&start=$start&premium=0")->json();
            PolymartResult::where('page', '=', $request->page)->delete();
            PolymartResult::create(['page' => $request->page, 'result' => $result]);
            return $result;
        } else {
            return $license;
        };
    }
    public function getCustom(Request $request) {
        $license = $this->checkLicense($request);

        if($license->getStatusCode() === 200) {
            return Http::get("http://$request->url/pluginslist.json")->json();
        } else {
            return $license;
    }
    }
}
