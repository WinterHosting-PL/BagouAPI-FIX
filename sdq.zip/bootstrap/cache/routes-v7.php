<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w6hGfPsLZWVpTiGv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/getautoinstaller' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OdjyOhfiXoPs8Pno',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/license' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kiuUODWMz9COe5I3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::71IpLF0zg241ajNd',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/plugins/bukkit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4r7CI8DzGRIppSEI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/plugins/spigot' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sF6aoMgD1FgtcMrz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/plugins/polymart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tHLCdeeDkFjmpWZw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/plugins/custom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OyXC7IkmENRCfLQi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/mcversions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i5OJt0uZKCQ8kzOR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/client/pterodactyl/mcversions/download' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ib6MjcLctZFTvZjW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OHp72PDupJU5IQWr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
    ),
    3 => 
    array (
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w6hGfPsLZWVpTiGv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000042e0000000000000000";}";s:4:"hash";s:44:"Kn9rFqQi+fhgeY8gG8YXgxHLbcCw7fR8fumO6avvTe8=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::w6hGfPsLZWVpTiGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OdjyOhfiXoPs8Pno' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/getautoinstaller',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\ClientController@getAutoInstaller',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\ClientController@getAutoInstaller',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl',
        'where' => 
        array (
        ),
        'as' => 'generated::OdjyOhfiXoPs8Pno',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kiuUODWMz9COe5I3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/client/pterodactyl/license',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\ClientController@getLicense',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\ClientController@getLicense',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl',
        'where' => 
        array (
        ),
        'as' => 'generated::kiuUODWMz9COe5I3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::71IpLF0zg241ajNd' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/client/pterodactyl/license',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\ClientController@deleteLicense',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\ClientController@deleteLicense',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl',
        'where' => 
        array (
        ),
        'as' => 'generated::71IpLF0zg241ajNd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4r7CI8DzGRIppSEI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/plugins/bukkit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getBukkit',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getBukkit',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl/plugins',
        'where' => 
        array (
        ),
        'as' => 'generated::4r7CI8DzGRIppSEI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sF6aoMgD1FgtcMrz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/plugins/spigot',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getSpigot',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getSpigot',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl/plugins',
        'where' => 
        array (
        ),
        'as' => 'generated::sF6aoMgD1FgtcMrz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tHLCdeeDkFjmpWZw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/plugins/polymart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getPolymart',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getPolymart',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl/plugins',
        'where' => 
        array (
        ),
        'as' => 'generated::tHLCdeeDkFjmpWZw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OyXC7IkmENRCfLQi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/plugins/custom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getCustom',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\PluginsController@getCustom',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl/plugins',
        'where' => 
        array (
        ),
        'as' => 'generated::OyXC7IkmENRCfLQi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i5OJt0uZKCQ8kzOR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/mcversions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\McVersionsController@getVersions',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\McVersionsController@getVersions',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl/mcversions',
        'where' => 
        array (
        ),
        'as' => 'generated::i5OJt0uZKCQ8kzOR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ib6MjcLctZFTvZjW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/client/pterodactyl/mcversions/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\McVersionsController@downloadVersion',
        'controller' => 'App\\Http\\Controllers\\Api\\Client\\Pterodactyl\\McVersionsController@downloadVersion',
        'namespace' => NULL,
        'prefix' => 'api/client/pterodactyl/mcversions',
        'where' => 
        array (
        ),
        'as' => 'generated::Ib6MjcLctZFTvZjW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OHp72PDupJU5IQWr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000004300000000000000000";}";s:4:"hash";s:44:"/a0slhB28M0IwJ3a+C458Xl8G1LaaTMMEE/tIBIEqws=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OHp72PDupJU5IQWr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
