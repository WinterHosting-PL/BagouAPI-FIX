<?php

use Illuminate\Support\Facades\Facade;

return [
    'key' => env('PTERODACTYLMARKETKEY', null),
];